function varargout = EQUSL(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @EQUSL_OpeningFcn, ...
                   'gui_OutputFcn',  @EQUSL_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function EQUSL_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

set(handles.pushbutton8,'enable','off');
set(handles.text1,'visible','off');
axes(handles.axes1);img=imread('.\Image\start.jpg','jpg');image(img);axis off;axis image;

tooltip = '<html>���� �̹��� �ҷ�����';
set(handles.pushbutton1,'tooltip',tooltip);
tooltip = '<html>�ؾȼ� ������ ����(���������� ����)';
set(handles.pushbutton2,'tooltip',tooltip);
tooltip = '<html>���� �ڷḦ Ȱ���� �ؾȼ��� fitting circle';
set(handles.pushbutton3,'tooltip',tooltip);
tooltip = '<html>�غ��� �������� ������ ������ ����';
set(handles.pushbutton4,'tooltip',tooltip);
tooltip = '<html>�ؾ� �������� ���⿡ ���� �������� �ؾȼ� ���� ����';
set(handles.pushbutton5,'tooltip',tooltip);
tooltip = '<html>���� ���';
set(handles.pushbutton8, 'tooltip',tooltip);
tooltip = '<html>Ȯ��(Left:Finish, Right:Continue)';
set(handles.pushbutton10,'tooltip',tooltip);
tooltip = '<html>���';
set(handles.pushbutton11,'tooltip',tooltip);
tooltip = '<html>�׷��� �ɼ�(Shoreline)';
set(handles.pushbutton12,'tooltip',tooltip);
tooltip = '<html>�׷��� �ɼ�(Focus)';
set(handles.pushbutton13,'tooltip',tooltip);
tooltip = '<html>������';
set(handles.pushbutton14,'tooltip',tooltip);
tooltip = '<html>���� ���';
set(handles.pushbutton15,'tooltip',tooltip);
tooltip = '<html>�̹��� ����';
set(handles.pushbutton16,'tooltip',tooltip);
tooltip = '<html>�ؾȼ� ������ ����(���������� ����)';
set(handles.pushbutton17,'tooltip',tooltip);

tooltip = '<html>C0 ������';
set(handles.edit1,'tooltip',tooltip);
tooltip = '<html>C1 ������';
set(handles.edit2,'tooltip',tooltip);
tooltip = '<html>C2 ������';
set(handles.edit3,'tooltip',tooltip);

function varargout = EQUSL_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;



% --- pushbutton1 : Open Image File
function pushbutton1_Callback(hObject, eventdata, handles)
global img img_s n col sty col1 sty1 x y
global p2 p3 p5 p17 p18 p33

% clear img img_s n p2 p3 p5 col sty col1 sty1
hold off;

[fn,pn] = uigetfile({'*.jpg';'*.png';'*.bmp';'*.*'},'Choose Satellite Image You Want...','./satellite image');
if isequal(fn,0)|isequal(pn,0)
    hmsg=msgbox('File not found');
    uiwait(hmsg);
    hold on;
else
    zi=imread([pn,fn]);
    z=double(zi);
    [x y z]=size(z)
    axes(handles.axes1)
    img = imread([pn,fn]);
    img_s = size(img);
    imshow(img);axis on;axis image;hold on;
    set(handles.text1,'visible','on');
end  

col = 'r';
sty = '-';
col1 = 'y';
sty1 = ':';

p2 = 0;
p3 = 0;
p5 = 0;
p17 = 0;
p18 = 0;
p33 = 1;
n = 1;

% --- pushbutton2 : All Clear
function pushbutton2_Callback(hObject, eventdata, handles)
global SD p2 p3 p5 img n cp p17 p18
 
if p2 == 0
    %%%�ʱ�ȭ
    axes(handles.axes1);
    cla;
    imshow(img);hold on;axis on;axis image;
    p3 = 0;
    p5 = 0;
    p17 = 0;
    p18 = 0;
    n = 1;
    set(handles.edit1,'string','0');
    set(handles.edit2,'string','0');
    set(handles.edit3,'string','0');
    cp = [];
    set(handles.pushbutton2,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton3,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton4,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton5,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton17,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    %%%

    SD = 1;
    set(handles.pushbutton8,'enable','on');
    set(handles.pushbutton2,'backgroundcolor','c','fontweight','b');
    p2 = 1;
else
    SD = 0;
    set(handles.pushbutton8,'enable','off');
    set(handles.pushbutton2,'backgroundcolor',[240/255 240/255 240/255]);
    p2 = 0;
end

% --- pushbutton17 : Shoreline Digitizing
function pushbutton17_Callback(hObject, eventdata, handles)
global SD p2 p3 p5 img n cp p17 p18

if p17 == 0
    %%%�ʱ�ȭ
    axes(handles.axes1);
    cla;
    imshow(img);hold on;axis on;axis image;
    p2 = 0;
    p3 = 0;
    p5 = 0;
    p18 = 0;
    n = 1;
    set(handles.edit1,'string','0');
    set(handles.edit2,'string','0');
    set(handles.edit3,'string','0');
    cp = [];
    set(handles.pushbutton2,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton3,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton4,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton5,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    set(handles.pushbutton17,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
    %%%
    
    SD = 1;
    set(handles.pushbutton8,'enable','on');
    set(handles.pushbutton17,'backgroundcolor','c','fontweight','b');
    p17 = 1;
else
    SD = 0;
    set(handles.pushbutton8,'enable','off');
    set(handles.pushbutton17,'backgroundcolor',[240/255 240/255 240/255]);
    p17 = 0;
end

% --- pushbutton3 : Fitted Circle Plotting
function pushbutton3_Callback(hObject, eventdata, handles)
global cp p3  x y
global col sty
global SD p2 p17 p18 p33
global pimg Nc RB

if p3 == 0
    SD = 0;
    set(handles.pushbutton8,'enable','off');
    set(handles.pushbutton2,'backgroundcolor',[240/255 240/255 240/255]);
    set(handles.pushbutton17,'backgroundcolor',[240/255 240/255 240/255]);
    p2 = 0;
    p17 = 0;
    
    set(handles.pushbutton3,'backgroundcolor','c','fontweight','b');
% ------------------------ intro(�Լ� �պκп� ÷��) -----------------------
    if length(cp) <= 2;
        hww=msgbox('Warning!!: ��꿡 3�� �̻��� ���� �ʿ��մϴ�.');
        uiwait(hww);
        return;
    end
    cth = str2num(get(handles.edit8,'string'))%*pi/180
    [RB,Oc,Nc,MWang] = fitcir(cp,cth);
    
    th = 0:0.01:2*pi;
    pimg.cir(p33*2-1) = plot([Nc(1) -RB*sin(MWang*pi/180)+Oc(1)],[Nc(2) RB*cos(MWang*pi/180)+Oc(2)],'c-');axis([0 y 0 x]);hold on
    pimg.cir(p33*2) = plot(RB*cos(th)+Nc(1),RB*sin(th)+Nc(2),'color',col,'linestyle',sty,'LineWidth',2);axis([0 y 0 x]);hold on;
    p33 = p33+1;
    set(handles.edit5,'string',num2str(MWang));
    p3 = 1;
else
    if(mod(p18,2) == 0);delete(pimg.cir);p33=1;end;
    set(handles.pushbutton3,'backgroundcolor',[240/255 240/255 240/255]);
    p3 = 0;
end

% --- pushbutton18 : hold on/off
function pushbutton18_Callback(hObject, eventdata, handles)
global p18
p18 = p18+1;
if mod(p18,2) == 1
    set(handles.pushbutton18,'string','hold on');
    set(handles.pushbutton18,'backgroundcolor','c','fontweight','b');
else
    set(handles.pushbutton18,'string','hold off');
    set(handles.pushbutton18,'backgroundcolor',[240/255 240/255 240/255],'fontweight','n');
end

% --- pushbutton4 : Focus Digitizing
function pushbutton4_Callback(hObject, eventdata, handles)
global bt a FCR FCang p5 ke
global col1 cf p4
global pimg Nc RB

set(handles.pushbutton4,'backgroundcolor','c','fontweight','b');
p5 = 0;
set(handles.pushbutton5,'backgroundcolor',[240/255 240/255 240/255]);

if p4 == 1
    button=questdlg('Warning!!: focus�� control point�� �ٽ� �����Ͻðڽ��ϱ�? Continue?',...
        'WARNING','Yes','No','Yes');
    switch button
        case 'No'
            
        case 'Yes'
            delete(pimg.fc)
            cf(1,:) = ginput(1);
            pimg.fc(1) = plot(cf(1,1),cf(1,2),'o','color',col1,'markerfacecolor',col1,'markersize',7);hold on;
            cf(2,:) = ginput(1);
            pimg.fc(2) = plot(cf(2,1),cf(2,2),'x','color',col1,'markerfacecolor',col1,'markersize',10,'linewidth',2);hold on
    end
else
    cf(1,:) = ginput(1);
    pimg.fc(1) = plot(cf(1,1),cf(1,2),'o','color',col1,'markerfacecolor',col1,'markersize',7);hold on;
    cf(2,:) = ginput(1);
    pimg.fc(2) = plot(cf(2,1),cf(2,2),'x','color',col1,'markerfacecolor',col1,'markersize',10,'linewidth',2);hold on;
end

FCR = sqrt((cf(1,1)-Nc(1))^2+(cf(1,2)-Nc(2))^2);
CPR = sqrt((cf(2,1)-Nc(1))^2+(cf(2,2)-Nc(2))^2);
a = CPR-FCR;
FCang = 180/pi*atan2(cf(1,1)-Nc(1),cf(1,2)-Nc(2));
FCang=mod(FCang,360);
CPang = 180/pi*atan2(cf(2,1)-Nc(1),cf(2,2)-Nc(2));
CPang=mod(CPang,360);
if abs(FCang-CPang)>180&FCang>CPang;CPang=CPang+360;end
if abs(FCang-CPang)>180&FCang<CPang;FCang=FCang+360;end

ke = 1;
if(FCang>CPang);ke=-1;end;
bt=180/pi*atan2(a,CPR*abs(CPang-FCang)*pi/180)
set(handles.edit6,'string',num2str(bt));

% [RB-FCR CPR-RB sqrt((cf(1,1)-cf(2,1))^2+(cf(1,2)-cf(2,2))^2) RB]

pause(0.5)
set(handles.pushbutton4,'backgroundcolor',[240/255 240/255 240/255]);p4 = 1;


% --- pushbutton5 : Equi. SL Plotting
function pushbutton5_Callback(hObject, eventdata, handles)
global bt a FCR FCang p5 ke
global col1 sty1
global pimg Nc RB

if p5 == 0
    if bt>40;
        button=questdlg('Warning!!: ��Ÿ�� 40������ Ŀ ���� Control Point�� �ƴϸ� �߸��� ����� ������ �� �ֽ��ϴ�. Continue?',...
            'WARNING','Yes','No','Yes');
        switch button
            case 'No'
                return
        end
    end
    SB=str2num(get(handles.edit7,'string'));
    [ro,tho,xe,ye,Ci] = parabolicEQsl(a,bt,SB,Nc,FCR,FCang,ke);
    set(handles.pushbutton5,'backgroundcolor','c','fontweight','b');
    set(handles.edit1,'string',num2str(Ci(1)));
    set(handles.edit2,'string',num2str(Ci(2)));
    set(handles.edit3,'string',num2str(Ci(3)));
    Ci

    ind = find(ro>0);
    pimg.eqsl = plot(xe(ind),ye(ind),'color',col1,'linestyle',sty1,'linewidth',2);hold on;
    
    p5 = 1;
else
    delete(pimg.eqsl)
    set(handles.pushbutton5,'backgroundcolor',[240/255 240/255 240/255]);
    p5 = 0;
end

% --- pushbutton8 : Delete
function pushbutton8_Callback(hObject, eventdata, handles)
global cp pimg

if ~isempty(cp)
    delete(pimg.cp(end))
    pimg.cp(end) = [];
    cp(end,:) = [];
end

% --- pushbutton10 : Zoom In
function pushbutton10_Callback(hObject, eventdata, handles)
global img_s

cont = 3;
while (1)
    if cont~=3
        break;
    end
    [zxp zyp cont] = ginput(1);
    zx = img_s(2)/5;
    zy = img_s(1)/5;
    crop = min(zx,zy);
    axes(handles.axes1)
    axis([zxp-crop zxp+crop zyp-crop zyp+crop]);axis off;%hold on;
end

% --- pushbutton11 : Zoom Out
function pushbutton11_Callback(hObject, eventdata, handles)
global img_s

zx = img_s(2);
zy = img_s(1);
axis([0 zx 0 zy])

% --- pushbutton12 : LS_S
function pushbutton12_Callback(hObject, eventdata, handles)
LS1

% --- pushbutton13 : LS_F
function pushbutton13_Callback(hObject, eventdata, handles)
LS2

% --- pushbutton14 : Exit
function pushbutton14_Callback(hObject, eventdata, handles)
fclose all;close all;clear all;clc;

% --- pushbutton15 : Delete
function pushbutton15_Callback(hObject, eventdata, handles)
global cf
global pimg
% struct.reset = get(handles.axes1,'Children');

if ~isempty(cf)
    delete(pimg.fc)
    cf = [];
end

% --- pushbutton16 : Save Image
function pushbutton16_Callback(hObject, eventdata, handles)
[fn, pn, filterIndex] = uiputfile({'*.jpg', 'JPG Image(*.jpg)';'*.png','PNG Image(*.png)';'*.bmp','BMP Image(*.bmp)'},'Save Satellite Image...','./satellite image');
if fn ~= 0
    if filterIndex == 1
        format = 'jpg';
    elseif filterIndex == 2
        format = 'png';
    else
        format = 'bmp';
    end
    
    fullPath = strcat(pn, fn);
    [pathstr, name, ext] = fileparts(fullPath);
    if isempty(ext)
        fullPath = strcat(fullPath, '.', format);
    end
    
    frame = getframe(handles.axes1);
    Image = frame2im(frame);
    imwrite(Image, fullPath, format);
end


function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
global SD n cp
global col pimg

if SD == 1
	point = get(handles.axes1,'currentpoint');
    pimg.cp(n) = plot(point(1,1),point(1,2),'o','color',col);
    cp(n,:) = [point(1,1) point(1,2)];
    n = n+1;
end



function edit1_Callback(hObject, eventdata, handles)
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit2_Callback(hObject, eventdata, handles)
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit3_Callback(hObject, eventdata, handles)
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit5_Callback(hObject, eventdata, handles)
function edit5_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit6_Callback(hObject, eventdata, handles)
function edit6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit7_Callback(hObject, eventdata, handles)
function edit7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit8_Callback(hObject, eventdata, handles)
function edit8_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

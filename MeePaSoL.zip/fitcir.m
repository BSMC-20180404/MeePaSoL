function [RB,Oc,Nc,MWang] = fitcir(cp,rth)
% draw fitting circle & main waveangle in image
% ------------------------------ Input data -------------------------------
% cp:points [x,y]
% rth:rotation angle (deg.)
% ------------------------------ Output data ------------------------------
% RB:radius
% Oc:center of circle (center of coordinate(rectangular) [x,y]
% Nc:rotation center of circle (center of coordinate(rectangular) [x,y]
% MWang:main waveangle
% -------------------------------------------------------------------------

% ------------------------ intro(�Լ� �պκп� ÷��) -----------------------
% if length(cp) <= 2;
%     hww=msgbox('Warning!!: ��꿡 3�� �̻��� ���� �ʿ��մϴ�.');
%     uiwait(hww);
%     return;
% end
% ------------------------------ find circle ------------------------------
A(:,1:2) = cp.*2; A(:,3) = ones(size(cp,1),1).*(-1);
Y = (cp(:,1).^2)+(cp(:,2).^2);
X = inv(A'*A)*A'*Y;
aa = X(1); bb = X(2); r = sqrt(aa^2+bb^2-X(3));
Oc = [aa bb]; RB = r;
% -------------------------- cal. main waveangle --------------------------
cpxm=(max(cp(:,1))-min(cp(:,1)))/2+min(cp(:,1));
cpym=(max(cp(:,2))-min(cp(:,2)))/2+min(cp(:,2));
Cang=180/pi*atan2(Oc(1)-cpxm,Oc(2)-cpym)-90;
Cang=mod(Cang+90,360);
MWang=180/pi*atan2(Oc(2)-cpym,Oc(1)-cpxm);
% MWang=round(MWang*10)/10;%10�� �ڸ� �ݿø�
MWang=mod(MWang+90,360);
% ---------------------------- rotation center ----------------------------
cth = rth*pi/180;
Nc = [cos(cth) -sin(cth);sin(cth) cos(cth)]...
    *[RB*sin(MWang*pi/180);-RB*cos(MWang*pi/180)]...
    +[-RB*sin(MWang*pi/180)+Oc(1);RB*cos(MWang*pi/180)+Oc(2)];
% Nc = [aa bb];
% -------------------------------------------------------------------------
% th = 0:0.01:2*pi;
% pimg.fitcircle(1) = plot([Nc(1) -RB*sin(MWang*pi/180)+Oc(1)],[Nc(2) RB*cos(MWang*pi/180)+Oc(2)],'c-');hold on
% pimg.fitcircle(2) = plot(RB*cos(th)+Nc(1),RB*sin(th)+Nc(2),'r:','LineWidth',2);hold on;
% -------------------------------------------------------------------------



function [ro,tho,xe,ye,Ci] = parabolicEQsl(a,bt,SB,Nc,FCR,FCang,kee)
% parabolic type of equilibrium shoreline
% ------------------------------ Input data -------------------------------
% a:length of Focus to shoreline
% bt:value of beta
% SB:penetration ratio
% Nc:Center of polar coordinate [x,y]
% FCR:Distance between Center and Focus
% FCang:Angle of Focus
% kee:parameter of diraction(left to right or right to left) (1 or -1)
% ------------------------------ Output data ------------------------------
% ro:r value (center of coordinate(polar) is Nc)
% tho:th value (center of coordinate(polar) is Nc)
% xe:x value (center of coordinate(rectangular) is Nc)
% ye:y value (center of coordinate(rectangular) is Nc)
% Ci:constant of parabolic type of equilibrium shoreline
% -------------------------------------------------------------------------

% ------------------------ intro(�Լ� �պκп� ÷��) -----------------------
% if bt>40;
%     button=questdlg('Warning!!: ��Ÿ�� 40������ Ŀ ���� Control Point�� �ƴϸ� �߸��� ����� ������ �� �ֽ��ϴ�. Continue?',...
%         'WARNING','Yes','No','Yes');
%     switch button
%         case 'No'
%             return
%     end
% end

% -------------------------------------------------------------------------
C0C = [0 0 0.05 0.02 0 0.1 0.2 0.3 0.5];
C1C = [1 1 1.05 1.2 1.35 1.7 1.95 2.3 2.5];
beta = [0 10 20 30 40 50 60 70 80];

C0 = round(interp1(beta,C0C,bt)*100)/100;
C1 = round(interp1(beta,C1C,bt)*100)/100;
C2 = 1-C0-C1;
Ci = [C0 C1 C2];
% -------------------------------------------------------------------------
thl = bt:0.1:180;
R = a/sin(bt*pi/180)*(C0+C1*(bt./thl)+C2*(bt./thl).^2);
% -------------------------------------------------------------------------
ro = FCR+R.*sin(thl*pi/180)+SB*(a-R.*sin(thl*pi/180));
tho = FCang+kee*180/pi*R.*cos(thl*pi/180)./ro;
xe = ro.*sin(tho*pi/180)+Nc(1);
ye = ro.*cos(tho*pi/180)+Nc(2);
% -------------------------------------------------------------------------
% ind = find(ro>0);
% pimg.esl = plot(xe(ind),ye(ind),'-.m','linewidth',2);hold on;
% -------------------------------------------------------------------------



function varargout = LS2(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @LS2_OpeningFcn, ...
                   'gui_OutputFcn',  @LS2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before LS2 is made visible.
function LS2_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
global col1 sty1
set(handles.radiobutton7,'value',1);
set(handles.radiobutton11,'value',1);
col1 = 'm';
sty1 = ':';

guidata(hObject, handles);

function varargout = LS2_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(1,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'r';
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(2,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'g';
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(3,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'b';
end


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(4,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'w';
end


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(5,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'c';
end


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(6,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'y';
end


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(7,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'm';
end


% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
global col1

check_hnds=[handles.radiobutton1 handles.radiobutton2 handles.radiobutton3 handles.radiobutton4...
    handles.radiobutton5 handles.radiobutton6 handles.radiobutton7 handles.radiobutton8];

ExChoice(8,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    col1 = 'k';
end


% --- Executes on button press in radiobutton9.
function radiobutton9_Callback(hObject, eventdata, handles)
global sty1

check_hnds=[handles.radiobutton9 handles.radiobutton10 handles.radiobutton11 handles.radiobutton12];

ExChoice(1,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    sty1 = '-';
end


% --- Executes on button press in radiobutton10.
function radiobutton10_Callback(hObject, eventdata, handles)
global sty1

check_hnds=[handles.radiobutton9 handles.radiobutton10 handles.radiobutton11 handles.radiobutton12];

ExChoice(2,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    sty1 = '--';
end


% --- Executes on button press in radiobutton11.
function radiobutton11_Callback(hObject, eventdata, handles)
global sty1

check_hnds=[handles.radiobutton9 handles.radiobutton10 handles.radiobutton11 handles.radiobutton12];

ExChoice(3,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    sty1 = ':';
end


% --- Executes on button press in radiobutton12.
function radiobutton12_Callback(hObject, eventdata, handles)
global sty1

check_hnds=[handles.radiobutton9 handles.radiobutton10 handles.radiobutton11 handles.radiobutton12];

ExChoice(4,check_hnds);

if (get(hObject,'Value') == get(hObject,'Max'))
    sty1 = '-.';
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
global col1 sty1

close;


%%%%% Sub-Function %%%%%
function ExChoice(state,check_hnds)
state_max=length(check_hnds);

if get(check_hnds(state),'value')==1
    set(check_hnds([1:(state-1),(state+1):state_max]),'value',0);
else
    set(check_hnds(state),'value',1);
end
